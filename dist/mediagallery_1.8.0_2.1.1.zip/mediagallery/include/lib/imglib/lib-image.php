<?php
// +--------------------------------------------------------------------------+
// | Media Gallery Plugin - Geeklog                                           |
// +--------------------------------------------------------------------------+
// | lib-image.php                                                            |
// |                                                                          |
// | glFusion media handling library.                                         |
// +--------------------------------------------------------------------------+
// | Based on the Media Gallery Plugin for glFusion CMS                       |
// | Copyright (C) 2002-2008 by the following authors:                        |
// |                                                                          |
// | Mark R. Evans          mark AT glfusion DOT org                          |
// +--------------------------------------------------------------------------+
// |                                                                          |
// | This program is free software; you can redistribute it and/or            |
// | modify it under the terms of the GNU General Public License              |
// | as published by the Free Software Foundation; either version 2           |
// | of the License, or (at your option) any later version.                   |
// |                                                                          |
// | This program is distributed in the hope that it will be useful,          |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            |
// | GNU General Public License for more details.                             |
// |                                                                          |
// | You should have received a copy of the GNU General Public License        |
// | along with this program; if not, write to the Free Software Foundation,  |
// | Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.          |
// |                                                                          |
// +--------------------------------------------------------------------------+
//

if (strpos(strtolower($_SERVER['PHP_SELF']), strtolower(basename(__FILE__))) !== false) {
    die('This file can not be used on its own!');
}

/*
 * Include the proper graphics support package
 */

switch ( $_CONF['image_lib'] ) {
    case 'imagemagick' :    // ImageMagick...
        require_once $_CONF['path'] . 'plugins/mediagallery/include/lib/imglib/im_image.php';
        break;
    case 'netpbm' :    // NetPBM
        require_once $_CONF['path'] . 'plugins/mediagallery/include/lib/imglib/pbm_image.php';
        break;
    case 'gdlib' :    // GD Library
        require_once $_CONF['path'] . 'plugins/mediagallery/include/lib/imglib/gd_image.php';
        break;
    default:
        require_once $_CONF['path'] . 'plugins/mediagallery/include/lib/imglib/gd_image.php';
        break;
}

/**
 * Check that the image backend selected in Geeklog is actually usable.
 *
 * MediaGallery historically assumed the configured backend was available.
 * With GD selected but the PHP GD extension missing, image uploads could end
 * in an undefined-function fatal while non-image uploads continued to work.
 * Keep the check centralized here so uploads, conversions, rotations and
 * watermarks all fail cleanly for the same reason.
 *
 * @return array bool availability and human-readable error message
 */
function MG_getImageBackendStatus180()
{
    global $_CONF, $_MG_CONF;

    $backend = isset($_CONF['image_lib']) ? strtolower(trim($_CONF['image_lib'])) : 'gdlib';
    if ($backend === '') {
        $backend = 'gdlib';
    }

    if ($backend === 'gdlib') {
        $required = array(
            'imagecreatetruecolor',
            'imagecreatefromjpeg',
            'imagecreatefrompng',
            'imagecreatefromgif',
        );
        foreach ($required as $function) {
            if (!function_exists($function)) {
                return array(
                    false,
                    'MediaGallery image processing is unavailable: GD is selected but the PHP GD extension is not loaded. Install/enable GD or configure ImageMagick/NetPBM in Geeklog.'
                );
            }
        }
        return array(true, '');
    }

    if (!function_exists('exec')) {
        return array(
            false,
            'MediaGallery image processing is unavailable: the selected external image backend requires PHP exec(), but exec() is disabled.'
        );
    }

    if ($backend === 'imagemagick') {
        $prefix = isset($_MG_CONF['path_to_imagemagick']) ? $_MG_CONF['path_to_imagemagick'] : '';
        if (!MG_imageCommandAvailable180($prefix, 'identify') || !MG_imageCommandAvailable180($prefix, 'convert')) {
            return array(
                false,
                'MediaGallery image processing is unavailable: ImageMagick is selected but the identify/convert commands cannot be executed. Check the ImageMagick path in Geeklog.'
            );
        }
        return array(true, '');
    }

    if ($backend === 'netpbm') {
        $prefix = isset($_CONF['path_to_netpbm']) ? $_CONF['path_to_netpbm'] : '';
        $hasScaler = MG_imageCommandAvailable180($prefix, 'pamscale') || MG_imageCommandAvailable180($prefix, 'pnmscale');
        if (!$hasScaler || !MG_imageCommandAvailable180($prefix, 'jpegtopnm') || !MG_imageCommandAvailable180($prefix, 'pnmtojpeg')) {
            return array(
                false,
                'MediaGallery image processing is unavailable: NetPBM is selected but required NetPBM commands cannot be executed. Check the NetPBM path in Geeklog.'
            );
        }
        return array(true, '');
    }

    return array(
        false,
        'MediaGallery image processing is unavailable: Geeklog image_lib is set to an unsupported backend (' . $backend . ').'
    );
}

/**
 * Resolve an external image command either from an explicit configured path
 * or from the process PATH. This intentionally does not execute the command.
 */
function MG_imageCommandAvailable180($prefix, $binary)
{
    $suffix = (PHP_OS === 'WINNT') ? '.exe' : '';
    $binary .= $suffix;
    $prefix = trim((string) $prefix);

    if ($prefix !== '') {
        $path = rtrim($prefix, '/\\') . DIRECTORY_SEPARATOR . $binary;
        if (!is_file($path)) {
            return false;
        }
        return (PHP_OS === 'WINNT') ? true : is_executable($path);
    }

    $output = array();
    $status = 1;
    if (PHP_OS === 'WINNT') {
        @exec('where ' . escapeshellarg($binary), $output, $status);
    } else {
        @exec('command -v ' . escapeshellarg($binary), $output, $status);
    }
    return $status === 0 && !empty($output);
}

/**
 * Common guard used immediately before an operation requires image processing.
 */
function MG_requireImageBackend180()
{
    static $logged = false;

    list($available, $message) = MG_getImageBackendStatus180();
    if (!$available && !$logged) {
        COM_errorLog($message, 1);
        $logged = true;
    }
    return array($available, $message);
}

/* - the next two calls need to move to a new library -- */


function UTL_exec($cmd) {
    global $_CONF;

    $debugfile = "";
    $status="";
    $results=array();
    if ($_CONF['debug_image_upload'] ) {
        COM_errorLog(sprintf("UTL_exec: Executing: %s",$cmd));
    }

    $debugfile = $_CONF['path'] . 'logs/debug.log';

    if (PHP_OS == "WINNT") {
//        $cmd .= ">NUL 2>&1";
        exec('"' . $cmd . '"', $results, $status);
    } else {
        exec($cmd, $results, $status);
    }

    return array($results, $status);
}

function UTL_execWrapper($cmd) {

    list($results, $status) = UTL_exec($cmd);

    if ( $status == 0 ) {
        return true;
    } else {
        COM_errorLog("UTL_execWrapper: Failed Command: " . $cmd);
        return false;
    }
}

/**
 * Returns the mime type and other meta data for an image or multi-media file.
 *
 *
 * @param   string  $filename   The absolute path to the media file
 *
 * @return  string  An array of meta data - mime_type will always be set.
 *
 */

function MG_getMediaMetaData( $filename ) {
    global $_CONF;

    // include getID3() library
    require_once $_CONF['path'] . 'plugins/mediagallery/include/lib/getid3/getid3.php';
    // Needed for windows only
    if (!defined('GETID3_HELPERAPPSDIR')) {
        define('GETID3_HELPERAPPSDIR', 'C:/helperapps/');
    }

    $getID3 = new getID3;

    // Analyze file and store returned data in $ThisFileInfo
    $ThisFileInfo = $getID3->analyze($filename);
    getid3_lib::CopyTagsToComments($ThisFileInfo);

    if ( $_CONF['debug_image_upload'] ) {
        COM_errorLog("MG_getMediaMetaData: getID3 analyzing file: " . $filename);
        COM_errorLog("MG_getMediaMetaData: getID3 found mime_type: " . $ThisFileInfo['mime_type']);
    }

    if ( isset($ThisFileInfo['error']) ) {
        if ( is_array($ThisFileInfo['error']) ) {
            foreach ($ThisFileInfo['error'] AS $error ) {
                COM_errorLog("MG_getMediaMetaData: " . $error);
            }
        }
    }

    return $ThisFileInfo;
}


//testing
function MG_helper_getImageWH($imgwidth, $imgheight, $maxwidth, $maxheight, $stretch=true)
{
    if ($imgwidth < $imgheight) {
        $tmp = $maxwidth;
        $maxwidth = $maxheight;
        $maxheight = $tmp;
    }

    if ($imgwidth > $maxwidth || $imgheight > $maxheight) {

        $ratio_width  = $imgwidth / $maxwidth;
        $ratio_height = $imgheight / $maxheight;
        if ($ratio_width > $ratio_height) {
            $newwidth = $maxwidth;
            $newheight = round($imgheight / $ratio_width);
        } else {
            $newheight = $maxheight;
            $newwidth = round($imgwidth / $ratio_height);
        }

    } else {
        if ($stretch == true) {

            if ($imgwidth > $imgheight) {
                $ratio_width  = $imgwidth / $maxwidth;
                $newwidth = $maxwidth;
                $newheight = round($imgheight / $ratio_width);
            } else {
                $ratio_height = $imgheight / $maxheight;
                $newheight = $maxheight;
                $newwidth = round($imgwidth / $ratio_height);
            }

        } else {
            $newwidth  = $imgwidth;
            $newheight = $imgheight;
        }
    }
    return array($newwidth, $newheight);
}

/**
 * Takes an image file and resizes it
 *
 * @param   string  $srcImage       Absolute path to the source image
 * @param   string  $destImage      Absolute path to the destination image
 * @param   string  $dImageHeight   Destination image height
 * @param   string  $dImageWidth    Destination image width
 * @param   string  $mimeType       Source image mime type, if known
 * @param   bool    $deleteSrc      Should the source image be deleted after resizing
 *
 * @return  array   Returns $rc and $msg. $msg will be set if there was an error
 *
 * Note: $srcImage and $destImage can be the same location in which case the
 *       original image will be resized
 */

function MG_resizeImage($srcImage, $destImage, $dImageHeight, $dImageWidth, $mimeType='', $deleteSrc=0, $JpegQuality=85) {
    list($backendAvailable, $backendMessage) = MG_requireImageBackend180();
    if (!$backendAvailable) {
        return array(false, $backendMessage);
    }

    global $_CONF, $_MG_CONF;

    if ( $dImageHeight == 0 ) {
        $dImageHeight = 200;
    }
    if ( $dImageWidth == 0 ) {
        $dImageWidth = 200;
    }

    $imgsize    = @getimagesize("$srcImage");
    $imgwidth   = $imgsize[0];
    $imgheight  = $imgsize[1];
    if ($imgwidth == 0 || $imgheight == 0 ) {
        $imgwidth   = $dImageWidth;
        $imgheight  = $dImageHeight;
    }

    if ( $mimeType == '' ) {
        $metaData = MG_getMediaMetaData($srcImage);
        $mimeType = $metaData['mime_type'];
    }

    if ( $mimeType == 'image/x-targa' || $mimeType == 'image/tga' ) {
        $fp = @fopen($srcImage,'rb');
        if ( $fp == false ) {
            return array(false,'Failed to open source TGA image.');
        }
        $data = fread($fp,filesize($srcImage));
        fclose($fp);
        $imgwidth  = base_convert(bin2hex(strrev(substr($data,12,2))),16,10);
        $imgheight = base_convert(bin2hex(strrev(substr($data,12,2))),16,10);
        COM_errorLog("TGA resolution: height: " . $imgheight . " width: " . $imgwidth);
    }

    // testing
    if ($imgwidth < $imgheight) {
        $tmp = $dImageWidth;
        $dImageWidth = $dImageHeight;
        $dImageHeight = $tmp;
    }


    if ( $imgwidth > $imgheight ) {
        $ratio = $imgwidth / $dImageWidth;
        $newwidth = $dImageWidth;
        $newheight = round($imgheight / $ratio);
    } else {
        $ratio = $imgheight / $dImageHeight;
        $newheight = $dImageHeight;
        $newwidth = round($imgwidth / $ratio);
    }

    // testing
    //list($newwidth, $newheight) = MG_helper_getImageWH($imgwidth, $imgheight, $dImageWidth, $dImageHeight, false);

    // check to see if srcImage is smaller than desired target,
    // if smaller, do not upsize, simply copy the src to the dest.

    if (($newheight > $imgheight) && ($newwidth > $imgwidth)) {
        $rc = copy($srcImage, $destImage);
        COM_errorLog("MG_resizeImage: Original (" . $srcImage . ") is smaller than target, original copied to target image (" . $destImage . ".");
        return array(true,'Original is smaller than target, original copied to target image.');
    }

    list($rc, $msg) = _img_resizeImage($srcImage, $destImage, $imgheight, $imgwidth, $newheight, $newwidth, $mimeType, $JpegQuality);
    if ($rc == false) {
        return array($rc, $msg);
    }

    return array(true,'Image successfully resized');
}

/*
 * Rotates an image left or right 90 degrees
 */

function MG_rotateImage($srcImage, $direction) {
    list($backendAvailable, $backendMessage) = MG_requireImageBackend180();
    if (!$backendAvailable) {
        return array(false, $backendMessage);
    }

    global $_CONF, $_MG_CONF;

    $metaData = MG_getMediaMetaData($srcImage);
    $mimeType = $metaData['mime_type'];

    /*
     * Check image format, jpegtan will only work for JPG images
     */

    if ( $_MG_CONF['jpegtran_enabled'] == 1 && ($mimeType == 'image/jpeg' || $mimeType == 'image/jpg') ) {
        switch( $direction ) {
            case 'right' :
                $JT_rotate = "90";
                break;
            case 'left' :
                $JT_rotate = "270";
                break;
            default :
                COM_errorLog("MG_rotateImage: Invalid direction passed to rotate, must be left or right");
                return array(false,'Invalid direction passed to rotate, must be left or right');
        }
        $tmpImage   = $srcImage . '.rt';

        $rc = UTL_execWrapper('"' . $_CONF['path_to_jpegtran'] . "/jpegtran" . '"' . " -rotate " . $JT_rotate . " -trim \"$srcImage\" > \"$tmpImage\"");

        if ( $rc != true ) {
            @unlink($tmpImage);
            return array(false,'IMG Rotate: Error rotating image');
        }
        clearstatcache();
        $rtFileSize = 0;
        $rtFileSize = @filesize($tmpImage);
        if ( $rtFileSize < 1 ) {
            @unlink($tmpImage);
            return array(false,'IMG Rotate: Error rotating image');
        }
        if ( $_MG_CONF['jhead_enabled'] == 1 ) {
            $rc = UTL_execWrapper('"' . $_CONF['jhead_path'] . "/jhead" . '"' . " -te " . $srcImage . " " . $tmpImage);
            COM_errorLog("MG_rotateImage: jhead returned " . $rc );
        }
        $rc = @copy($tmpImage, $srcImage);
        @unlink($tmpImage);
        return array(true,'');
    } else {
        list($rc,$msg) = _img_RotateImage($srcImage, $direction, $mimeType);
        return array($rc,$msg);
    }
}

/*
 * convert an image from one format to another
 */

function MG_convertImageFormat( $srcImage, $destImage, $destFormat, $deleteOriginal=1 ) {
    list($backendAvailable, $backendMessage) = MG_requireImageBackend180();
    if (!$backendAvailable) {
        return array(false, $backendMessage);
    }

    global $_CONF;

    $newSrc = $srcImage;

    if ($_CONF['debug_image_upload']) {
        COM_errorLog("MG_convertImageFormat: Entering MG_convertImageFormat()");
    }

    $metaData = array();

    $metaData = MG_getMediaMetaData($srcImage);
    $mimeType = $metaData['mime_type'];

    $imgsize = @getimagesize($srcImage);
    if ( $imgsize == false &&
         $mimeType != 'image/x-targa' &&
         $mimeType != 'image/tga' &&
         $mimeType != 'image/photoshop' &&
         $mimeType != 'image/x-photoshop' &&
         $mimeType != 'image/psd' &&
         $mimeType != 'application/photoshop' &&
         $mimeType != 'application/psd' &&
         $mimeType != 'image/tiff' ) {
        COM_errorLog("MG_convertImageFormat: Error - unable to retrieve srcImage resolution");
        return array(false,'Unable to determine source image resolution');
    }

    $imgwidth = $imgsize[0];
    $imgheight = $imgsize[1];

    if ($imgsize == false || $imgwidth == 0 || $imgheight == 0 ) {
        $imgwidth = 620;
        $imgheight = 465;
    }
    if ( $mimeType == $destFormat ) {
        if ( $srcImage != $destImage ) {
            $rc = copy($srcImage, $destImage);
        }
        return array(true,'Original image copied to destination image.');
    }

    list($rc,$msg) = _img_convertImageFormat($srcImage,$destImage,$destFormat, $mimeType);

    return array($rc,$msg);
}

function MG_watermarkImage( $origImage, $watermarkImage, $opacity, $location ) {
    list($backendAvailable, $backendMessage) = MG_requireImageBackend180();
    if (!$backendAvailable) {
        return array(false, $backendMessage);
    }

    global $_MG_CONF, $_CONF;

    if ( $_CONF['debug_image_upload'] ) {
        COM_errorLog("MG_watermarkImage: Entering MG_watermarkImage()");
    }

    $mType = MG_getMediaMetaData($origImage);
    $mimeType = $mType['mime_type'];

    if ( !in_array($mimeType,$_MG_CONF['watermark_types']) ) {
        COM_errorLog("MG_watermarkImage: Media type is not in allowed watermark types (config.php)");
        return false;
    }

    list($rc,$msg) = _img_watermarkImage($origImage, $watermarkImage, $opacity, $location, $mimeType );
    return array($rc,$msg);
}

/**
 * Takes an image file and resizes it
 *
 * @param   string  $srcImage       Absolute path to the source image
 * @param   string  $destImage      Absolute path to the destination image
 * @param   string  $dImageHeight   Destination image height
 * @param   string  $dImageWidth    Destination image width
 * @param   string  $mimeType       Source image mime type, if known
 * @param   bool    $deleteSrc      Should the source image be deleted after resizing
 *
 * @return  array   Returns $rc and $msg. $msg will be set if there was an error
 *
 * Note: $srcImage and $destImage can be the same location in which case the
 *       original image will be resized
 */
// added by dengen
function MG_resizeImage_crop($srcImage, $destImage, $dImageHeight, $dImageWidth, $mimeType='', $deleteSrc=0, $JpegQuality=85) {
    global $_CONF;

    if ( $dImageHeight == 0 ) {
        $dImageHeight = 200;
    }
    if ( $dImageWidth == 0 ) {
        $dImageWidth = 200;
    }

    $imgsize    = @getimagesize("$srcImage");
    $imgwidth   = $imgsize[0];
    $imgheight  = $imgsize[1];
    if ($imgwidth == 0 || $imgheight == 0 ) {
        $imgwidth   = $dImageWidth;
        $imgheight  = $dImageHeight;
    }

    if ( $mimeType == '' ) {
        $metaData = MG_getMediaMetaData($srcImage);
        $mimeType = $metaData['mime_type'];
    }

    if ( $mimeType == 'image/x-targa' || $mimeType == 'image/tga' ) {
        $fp = @fopen($srcImage,'rb');
        if ( $fp == false ) {
            return array(false,'Failed to open source TGA image.');
        }
        $data = fread($fp,filesize($srcImage));
        fclose($fp);
        $imgwidth = base_convert(bin2hex(strrev(substr($data,12,2))),16,10);
        $imgheight = base_convert(bin2hex(strrev(substr($data,12,2))),16,10);
        COM_errorLog("TGA resolution: height: " . $imgheight . " width: " . $imgwidth);
    }

    $dAspectRatio = $dImageWidth / $dImageHeight;
    $sAspectRatio = $imgwidth / $imgheight;
    $newwidth  = $dImageWidth;
    $newheight = $dImageHeight;
    $new_x = 0;
    $new_y = 0;

    if ( $dAspectRatio > $sAspectRatio ) {
        
        $src_w = $imgwidth;
        $src_h = intval(round($imgwidth / $dAspectRatio));
        $src_x = 0;
        $src_y = intval(round(($imgheight - $src_h) / 2));

    } else {

        $src_w = intval(round($imgheight * $dAspectRatio));
        $src_h = $imgheight;
        $src_x = intval(round(($imgwidth - $src_w) / 2));
        $src_y = 0;
    }

    // check to see if srcImage is smaller than desired target,
    // if smaller, do not upsize, simply copy the src to the dest.

    if (($newheight > $imgheight) && ($newwidth > $imgwidth)) {
        $rc = copy($srcImage, $destImage);
        COM_errorLog("MG_resizeImage_square: Original (" . $srcImage . ") is smaller than target, original copied to target image (" . $destImage . ".");
        return array(true,'Original is smaller than target, original copied to target image.');
    }

    list($rc,$msg) = _img_resizeImage_crop($srcImage, $destImage,
                                           $src_x, $src_y,
                                           $new_x, $new_y,
                                           $src_h, $src_w,
                                           $newheight, $newwidth,
                                           $mimeType,
                                           $JpegQuality);
    if ( $rc == false ) {
        return array($rc,$msg);
    }
    return array(true,'Image successfully resized');
}

