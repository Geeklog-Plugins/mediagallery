# MediaGallery 1.8.0 online test checklist

Use the installable archive in `dist/mediagallery_1.8.0_2.1.1.zip` only after the distribution workflow has rebuilt it from the current `modernize-1.8.0` branch.

## Fresh installation

Test on Geeklog 2.1.1 and 2.2.2 where available.

- Install MediaGallery 1.8.0 through the standard plugin installer.
- Open the MediaGallery Configuration page.
- Confirm there is no FlowPlayer option and no Flash Media configuration tab.
- Confirm the remaining MP3/MOV/ASF controls load without PHP warnings.
- Confirm MediaGallery public pages load before any media is uploaded.

## Image upload and DNC

Use small PNG, GIF, BMP and JPEG samples.

### DNC disabled

With `discard_original = 0` and **Do not convert original to JPG** unchecked:

- upload PNG/GIF/BMP;
- confirm upload completes without warning;
- confirm the retained original is a real JPEG file;
- confirm its stored extension is `.jpg` and MediaGallery records JPEG MIME data;
- confirm thumbnail and display images render normally.

### DNC enabled

With **Do not convert original to JPG** checked:

- upload PNG/GIF/BMP;
- confirm the original retains its source format and extension;
- confirm thumbnail and display images render normally.

### Discard original

With `discard_original = 1`, repeat one PNG/JPEG upload and confirm no orphan original or incorrect MIME record is created.

## Legacy media playback

- Open an existing MP3/WMA media item and verify HTML5 audio playback/fallback.
- Exercise MP3 popup, download and MMS/legacy modes and confirm no undefined thumbnail-size warning appears.
- Open MOV/MP4/MPEG media inline and verify HTML5 video rendering.
- Exercise MOV/ASF popup and download modes and confirm no `media_size_disp` warning appears.
- Open existing SWF and FLV items and verify they are offered through the generic download fallback without Flash/FlowPlayer execution or PHP warnings.
- Test an old `fslideshow.php` URL and an existing `fslideshow` autotag.

## Upload security

- Browser upload with a valid CSRF token succeeds.
- Missing/invalid CSRF submission is rejected.
- Four simultaneous upload slots preserve their own title, description, keywords, category, attached-thumbnail and DNC values.
- Executable/double-extension test names are rejected.
- FTP import accepts a file inside configured `ftp_path` and rejects a forged outside path or escaping symlink.
- Remote Media accepts a normal public HTTP(S) thumbnail and rejects localhost/private/reserved targets.

## Batch-session security

- Start a resize/rebuild or media batch action and confirm automatic continuation still advances the session.
- Confirm continuation is submitted through POST and rejects a direct GET request.
- Confirm missing or invalid CSRF tokens are rejected.
- Confirm the session owner can continue and cancel the session.
- Confirm another normal user cannot continue or cancel the session.
- Confirm a MediaGallery administrator can recover/terminate an eligible session.

## Moderation

Run these checks with an album that has moderation enabled.

- Upload a media item as a normal member and confirm the row is stored in `mg_mediaqueue` with its relation in `mg_media_album_queue`, not in the active media tables.
- Confirm the MediaGallery submission appears in Geeklog's native moderation screen.
- Confirm a user with `mediagallery.admin` can open **Edit** even when that user does not have `mediagallery.config`.
- Confirm the same user cannot access the normal MediaGallery configuration pages without `mediagallery.config`.
- Edit a queued item's title/description and confirm the queued media remains bound to its original album.
- Forge a different `album_id` while saving a queued item and confirm the save is rejected.
- Approve a submission and confirm its full media row moves from `mg_mediaqueue` to `mg_media`, its album relation moves to `mg_media_albums`, the queue rows disappear and the album counter is correct.
- Confirm the approved media renders normally and the approval notification is sent when mail is configured.
- Reject a submission and confirm both queue rows disappear.
- Confirm rejection removes the original, display image and all generated thumbnail sizes without affecting unrelated media.
- Confirm moderation mutations are rejected for a user without `mediagallery.admin`.

## Persistent media storage

On a standard single-site installation:

- confirm `path_mediaobjects` resolves below `public_html/images/mediagallery/`;
- upload an image and confirm `orig`, `disp` and `tn` files are created there;
- re-upload the same MediaGallery 1.8.0 plugin ZIP and confirm the existing image remains intact;
- confirm placeholder/type assets such as `missing.png` and `generic.png` are present in persistent storage.

On a shared-code installation with site-specific `path_images`, `images_url` and `path_data`:

- confirm each site resolves its own `mediagallery` media path and URL;
- confirm `tmp` and FTP/upload staging directories are site-specific;
- confirm uploads on one site do not appear in another site's storage.

## Upgrade from 1.7.x

On disposable copies only:

- back up the database and `public_html/mediagallery/mediaobjects/`;
- extract the 1.8.0 package without installing it;
- run `php tools/migrate-media-storage.php /path/to/geeklog`;
- confirm the tool reports all source files verified in the persistent destination and leaves the source untouched;
- only then upload the 1.8.0 ZIP through Geeklog;
- test both MediaGallery 1.7.0 and 1.7.3 sources;
- confirm existing albums/media remain accessible from the new images storage;
- confirm existing administrator settings are preserved;
- confirm re-running the migration is idempotent;
- create a conflicting destination file with a different size and confirm migration fails without overwriting it;
- confirm a site containing only remote-media records does not falsely require local media files;
- confirm obsolete Flash/FlowPlayer configuration rows, if still present in the database, do not affect the 1.8 runtime.

Record PHP warnings/notices together with the Geeklog version, PHP version, action performed and relevant MediaGallery settings.

## Structured data

- Validate JSON-LD on a local image, local audio, video with attached thumbnail, video without attached thumbnail, and remote/embed media. Only the first three eligible cases should emit media structured data.

## Interoperability / lifecycle events

- [ ] Creating or editing a public album emits `PLG_itemSaved('album:<id>', 'mediagallery')`.
- [ ] Making an album private causes consumers using `PLG_getItemInfo(..., uid=1)` to receive no public URL.
- [ ] Deleting an album emits `PLG_itemDeleted('album:<id>', 'mediagallery')`, including recursive child deletion.
- [ ] Adding, editing or deleting media keeps the existing media lifecycle event and also announces the affected album page.
- [ ] Moving media announces the media item plus both source and destination albums.
- [ ] `plugin_getiteminfo_mediagallery('album:<id>', 'url', 1)` returns the public album URL only when anonymously readable.
- [ ] The same lifecycle behavior works on Geeklog 2.1.1 and 2.2.2 without requiring the newer `sub_type` argument.
