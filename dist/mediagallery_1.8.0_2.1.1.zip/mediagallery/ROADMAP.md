# MediaGallery 1.8.0 Roadmap

MediaGallery 1.8.0 is a modernization and hardening release focused on safe upgrades, persistent media storage, Geeklog 2.1.1+ compatibility, multisite isolation, upload security, removal of obsolete playback technologies, template/SEO/accessibility improvements, and interoperability with other Geeklog plugins.

The working branch is `modernize-1.8.0`. The supported Geeklog baseline is 2.1.1; Geeklog 2.0.x is not a target for 1.8.0.

This roadmap reflects the current implementation state. Completed items are checked; remaining work is concentrated around release-candidate validation and final cleanup.

## 1. Compatibility and release baseline

- [x] Require Geeklog 2.1.1 or newer.
- [x] Validate current runtime behavior on Geeklog 2.1.1 and 2.2.2.
- [x] Keep syntax compatible with PHP 5.6, 7.4, 8.1 and 8.3 while this compatibility policy remains in force.
- [x] Keep PHP lint CI green on the supported syntax range.
- [x] Avoid Geeklog core modifications.
- [x] Do not reintroduce the historical MediaGallery `config.php`.
- [x] Preserve existing database content and administrator configuration during upgrade.
- [x] Complete the static PHP 8.2/8.3 audit of MediaGallery-owned hot paths, including removed APIs, legacy globals, undefined variables and dynamic-property candidates.
- [ ] Complete the live PHP 8.2/8.3 runtime warning/deprecation audit before RC.
- [ ] Run the final regression matrix on Geeklog 2.1.1 and 2.2.2.

## 2. Persistent media storage and multisite

Media files are persistent user data and no longer live inside the replaceable plugin public directory.

MediaGallery 1.8.0 uses:

```php
$_MG_CONF['path_mediaobjects'] = rtrim($_CONF['path_images'], '/\\') . '/mediagallery/';
```

The historical `public_html/mediagallery/mediaobjects/` location is a legacy migration source only.

- [x] Centralize storage path/URL resolution.
- [x] Store all 1.8 public media under `path_images/mediagallery/`.
- [x] Keep shared-code multisite media isolated through each site's `path_images` / `images_url` pair.
- [x] Keep temporary/upload staging isolated under each site's `path_data/mediagallery/`.
- [x] Avoid `HTTP_HOST`-derived site identity.
- [x] Create required public/private storage directories with explicit error handling.
- [x] Implement copy-and-verify legacy-media migration in `include/storage_180.php`.
- [x] Never delete the legacy source automatically during migration.
- [x] Refuse conflicting destination files instead of silently overwriting them.
- [x] Provide `tools/migrate-media-storage.php` for safe 1.7.x pre-migration.
- [x] Protect subsequent ZIP upgrades because persistent media now live outside `public_html/mediagallery/`.
- [x] Propagate migration failures so a failed upgrade cannot be marked as installed successfully.
- [x] Confirm that adding media and then re-uploading the plugin ZIP preserves existing media on tested 2.1.1/2.2.2 installations.
- [ ] Validate the pre-migration path on disposable 1.7.0 and 1.7.3 copies.

### Legacy ZIP upgrade rule

Geeklog's plugin uploader replaces the old public plugin directory before loading the new plugin's upgrade code. A 1.7.x installation still storing media in `public_html/mediagallery/mediaobjects/` must therefore run the provided pre-migration tool before uploading the 1.8 ZIP.

## 3. Configuration API cleanup

- [x] Add `include/config_180.php` for runtime configuration and 1.8 migration.
- [x] Add missing Configuration API entries without resetting existing values.
- [x] Correctly distinguish missing settings from valid `0` / `false` settings.
- [x] Keep calculated/internal values out of administrator-editable configuration.
- [x] Remove fresh-install FlowPlayer configuration.
- [x] Remove fresh-install Flash Media configuration controls.
- [x] Keep obsolete legacy rows harmless on upgraded sites where deletion has not yet been proven safe.
- [ ] Verify whether obsolete 1.7.x Flash/FlowPlayer `conf_values` rows can be safely removed on both Geeklog 2.1.1 and 2.2.2.
- [x] Review remaining legacy playback-related controls and remove settings with no useful HTML5 equivalent.

## 4. Upload, import and remote-media security

- [x] Geeklog CSRF protection on browser upload, Remote Media and FTP import forms.
- [x] Correct browser slot association for captions, descriptions, keywords, category, attached thumbnail and DNC.
- [x] Correct DNC handling and preservation of originals when requested.
- [x] Real format conversion when DNC is disabled instead of only changing MIME/extension metadata.
- [x] Unsafe executable/server-side filename rejection.
- [x] Defense-in-depth filename validation inside `MG_getFile()`.
- [x] FTP source confinement with `realpath()`.
- [x] Revalidation of hidden FTP paths and recursive batch sources.
- [x] Batch continuation/cancellation ownership validation.
- [x] CLI import filename protection.
- [x] Harden ZIP extraction against path traversal, unsafe temporary paths, symlinks, excessive entry counts and declared uncompressed payloads above 1 GiB before extraction.
- [x] Harden recursive CLI imports by refusing symbolic links and preserving the intended subdirectory-to-subalbum mapping.
- [x] Remote Media restricted to public HTTP(S), with private/reserved/localhost rejection, redirect blocking and bounded downloads.
- [x] Root Album (`album_id=0`) upload prevention.
- [x] Prefer content-derived MIME (`getID3`, then `fileinfo`) and validate MIME/extension coherence for explicitly handled formats while leaving unknown extensions generic.
- [ ] Live-test MIME mismatch rejection and generic-file compatibility on Geeklog 2.1.1 and 2.2.2.
- [x] Clean deterministic upload-failure and special-image `wip` temporary files.
- [x] Add conservative stale-temp cleanup for genuinely interrupted/killed requests: private MediaGallery tmp only, 48-hour age threshold, no symlink traversal, and at most one scan per hour.
- [ ] Live-test stale-temp cleanup with old and recent files/directories on Geeklog 2.1.1 and 2.2.2.
- [x] Add CSRF protection to global album permission/attribute mutations and watermark manage/upload/delete mutations while preserving their existing access rules.
- [x] Harden album/static sort mutations with Geeklog CSRF tokens and revalidate static-sort album write access server-side.
- [x] Harden resize/rebuild confirmations, media manager save/delete/move/batch actions and direct rotation with Geeklog CSRF tokens; direct rotation now uses POST and revalidates album write access plus album/media membership.
- [x] Revalidate media edit/reset mutations server-side and correct reset handlers to read their posted album id.
- [x] Bind posted media IDs to the authorized album before manager edits, batch delete/move/rotate/watermark, cover selection and normal media editing.
- [x] Remove the orphaned legacy batch-caption mutation; make batch continuation/cancellation POST+CSRF only and bind session deletion to the owning user (administrator override).
- [x] Audit and repair Geeklog-native moderation: preserve core POST/CSRF handling, revalidate `mediagallery.admin` and queued album/media membership, correctly promote queue rows into active media tables on approval, fully remove rejected queue rows/files, and allow moderation edit/save without granting configuration access.
- [ ] Live-test the full moderation queue/edit/approve/reject flow on Geeklog 2.1.1 and 2.2.2.
- [x] Remove the orphaned legacy asynchronous upload endpoint and its dedicated `MG_saveUpload()` handler after confirming the active browser upload uses `admin.php` / `MG_saveUserUpload()`.

## 5. Image-processing backend requirements

Image upload requires a working image-processing backend for thumbnail/display generation. PDF/ZIP uploads can work even when no image backend is available.

The Geeklog 2.1.1 / PHP 5.6 validation confirmed that image uploads succeed once GD is installed.

- [x] Confirm image upload on Geeklog 2.1.1 / PHP 5.6 with GD available.
- [x] Confirm persistent image output under `images/mediagallery/`.
- [x] Add centralized runtime capability detection for GD, ImageMagick and NetPBM.
- [x] Guard resize, conversion, rotation and watermark operations before backend-specific calls.
- [x] Return a clear MediaGallery error when the configured backend is unavailable instead of reaching undefined image functions.
- [x] Document image-backend requirements in the development README.
- [ ] Validate the new missing-backend error live once with GD intentionally disabled on the Geeklog 2.1.1/PHP 5.6 test instance.

## 6. Playback modernization

- [x] Remove executable Flash playback from default rendering.
- [x] Replace QuickTime/Windows Media ActiveX paths with HTML5 video/audio or download fallback.
- [x] Route MPEG/MOV/MP4 through maintained HTML5 rendering.
- [x] Move MP3/WMA playback to HTML5 audio where meaningful.
- [x] Replace FLV/SWF playback with safe download fallbacks.
- [x] Replace XSPF Flash play-all/radio paths with maintained album/playlist fallbacks.
- [x] Redirect legacy `fslideshow.php` to the maintained slideshow.
- [x] Remove unused SWF binaries, SWFObject helper code and duplicate obsolete JavaScript assets.
- [x] Remove fresh-install SWF configuration dependencies.
- [x] Fix undefined `$media_size_disp` use in legacy popup/download rendering.
- [x] Keep only playback dimensions/mode behavior that still affects HTML5 rendering; legacy ActiveX/QuickTime-specific flags remain compatibility data and are ignored by maintained templates.
- [x] Preserve legacy per-media playback rows for upgrade/custom-skin compatibility, but do not reintroduce obsolete player behavior in maintained HTML5 templates.
- [x] Retire generated `mms:` playback links; legacy playback mode 3 now falls back to the normal MediaGallery download path.

## 7. Email modernization

- [x] Replace the bundled PHPMailer-based moderator notification path.
- [x] Use Geeklog `COM_mail()` transport.
- [x] Provide HTML and plaintext notification templates.
- [x] Preserve notification permissions and throttle behavior.
- [ ] Complete a live moderator-email test through the configured Geeklog mail backend before RC.

## 8. Templates, accessibility and SEO
- [x] Replace the legacy slideshow chrome with an immersive native lightbox-style viewer (keyboard, swipe, autoplay, reduced-motion support) while keeping album/media pages as the SEO/AI surfaces.

- [x] Semantic `<h1>` album titles.
- [x] Navigation landmarks and accessible album search control.
- [x] Semantic thumbnail wrappers.
- [x] Canonical URLs on individual media pages.
- [x] Self-canonical album pagination while excluding sort variants.
- [x] Page-number suffix in album titles on page 2+.
- [x] Correct sort-form page indexing.
- [x] Improve HTML attribute escaping in media popup output.
- [x] Review remaining inline presentation styles.
  - [x] Remove dead playback templates and migrate the largest active public/admin static style clusters to responsive CSS.
  - [x] Resolve all static inline presentation styles; retain only justified runtime dimensions used by responsive autotag/media sizing.
- [x] Modernize default album/search/media rendering with responsive CSS Grid/Flexbox, semantic media/card headings and responsive thumbnail frames.
- [x] Modernize bundled file-list, podcast, jQuery gallery and SimpleViewer skins for responsive layouts and semantic album headings.
- [x] Complete final public markup audit: one H1 per Podcast page, semantic repeated-card headings, non-link anchors and table-free member enrollment.
- [x] Modernize the default media-detail page with semantic article/figure markup, separated navigation/actions, compact metadata and normalized keyword tags.
- [x] Modernize the default album page with centered auto-fit cards, compact metadata, unified controls and a responsive footer.
- [x] Refine Root Album and media-detail controls: use Geeklog short-date formatting, lighter subalbum cards and compact media actions.
- [x] Simplify default album cards to title, short date, views/comments only; keep rating, tags and technical detail on media-detail pages.
- [x] Replace the public advanced-search presentation tables with a semantic responsive search form.
- [x] Modernize secondary public autotag, random-block, fullscreen-slideshow and maintained HTML5 audio rendering for responsive output.
- [x] Modernize active media popups, public profile tables and remaining audio fragments for responsive rendering.
- [x] Add canonical-safe meta descriptions for public album and media pages from existing editorial descriptions.
- [x] Remove the legacy IE-only slideshow transition code and keep browser-neutral slideshow controls.
- [x] Audit attribute escaping across all frame/theme variants.
- [x] Centralize HTML escaping for framed-image attributes, media edit/manage values, lightbox links and advanced-search values.
- [x] Replace the lightbox slideshow href-injection workaround with valid escaped album-action attributes across maintained album themes.
- [x] Escape editable album/category values and generated admin option labels when rendering form controls.
- [x] Remove dynamic property URLs from inline JavaScript and preserve lightbox slideshow actions on media detail views.
- [x] Remove translated delete-confirmation text from JavaScript string literals and escape it for HTML data attributes.
- [x] Escape persisted legacy playback text/color values when rendering maintained edit-form attributes.
- [x] Review keyboard accessibility and form labeling across remaining admin/public templates.
  - [x] Connect primary album/category, batch, export and user-quota controls to explicit labels; retain already-valid implicit FTP radio labels.
  - [x] Remove obsolete per-media playback controls instead of labeling settings that no longer affect HTML5 rendering; retain only video width/height controls.
  - [x] Label generated media-manager controls, row fields, destination album and batch-action selectors without changing array bindings.
  - [x] Label global album-management update controls plus member/purge/session/watermark maintenance forms.
- [x] Add structured data only where MediaGallery has reliable source data and does not conflict with Geeklog core/theme output.
  - [x] Emit conservative JSON-LD for local `ImageObject` / `AudioObject`, and `VideoObject` only when a real attached thumbnail and upload date are available.
  - [x] Skip remote/embedded media whose content, thumbnail or publication metadata MediaGallery does not own.
  - [x] Do not add album-level `CollectionPage` JSON-LD while generic page-schema ownership may belong to Geeklog core/themes.

## 9. Interoperability and public API

MediaGallery 1.8.0 exposes album discovery through Geeklog's native service convention:

```php
PLG_invokeService(
    'mediagallery',
    'album_list',
    array(
        'uid'       => $uid,
        'root'      => 'member',
        'recursive' => true,
        'visible'   => true,
    ),
    $output,
    $svc_msg
);
```

- [x] Implement `album_list` through `PLG_invokeService()`.
- [x] Reuse MediaGallery permission and album-tree rules rather than expose raw `mg_*` tables.
- [x] Preserve valid `member_album_root = 0` semantics.
- [ ] Complete live tests as owner, non-owner, anonymous user and administrator.

## 10. Code modernization and cleanup

- [x] Prefer Geeklog APIs where practical instead of duplicating core behavior.
- [x] Add Geeklog 2.1.1 input compatibility without core changes.
- [x] Validate request/array values in several historically unsafe paths.
- [x] Centralize 1.8 storage/runtime compatibility helpers.
- [x] Remove dead Flash/ActiveX playback assets and code paths already replaced.
- [x] Complete static PHP 8.x warning/deprecation cleanup in MediaGallery-owned hot paths, including RSS/feed generation, JPEG/EXIF metadata paths and register_globals-era logging.
- [ ] Complete live PHP 8.2/8.3 warning/deprecation validation on Geeklog 2.1.1 and 2.2.2.
- [ ] Fold `functions_legacy.inc` back into a clean final bootstrap if practical before RC.
- [ ] Remove confirmed dead compatibility branches once final supported versions are fixed.
- [x] Review and harden ZIP extraction plus remaining recursive CLI import paths.

## 11. Distribution

- [x] Use one installable archive: `dist/mediagallery_1.8.0_2.1.1.zip`.
- [x] Keep one top-level `mediagallery/` directory in the ZIP.
- [x] Exclude `.github/`, `dist/`, `.gitignore` and build-only directories.
- [x] Validate archive filenames against Geeklog 2.2.2 filename rules.
- [x] Validate presence of the 1.8 storage and migration helpers in the archive.
- [x] Rebuild the test archive automatically after every validated branch change, excluding `dist/**` to prevent loops.
- [ ] Rebuild the final RC archive only after remaining source/documentation changes are complete.

## 12. Release-candidate validation matrix

### Fresh installs

- [ ] Fresh 1.8.0 on Geeklog 2.1.1.
- [ ] Fresh 1.8.0 on Geeklog 2.2.2.
- [ ] Confirm Configuration UI has no obsolete FlowPlayer/Flash controls.
- [ ] Confirm upload/edit/delete, thumbnail generation, RSS, search and comments.
- [ ] Confirm clear failure/message when no image backend is available.

### Upgrades

- [ ] Upgrade disposable MediaGallery 1.7.0 copy.
- [ ] Upgrade disposable MediaGallery 1.7.3 copy.
- [ ] Run pre-migration to `images/mediagallery/` and verify source remains untouched.
- [ ] Confirm migration is idempotent.
- [ ] Confirm conflicting destination files fail safely without overwrite.
- [ ] Confirm legacy upgrade without preflight is refused when local-media rows exist but files are unavailable.
- [ ] Confirm administrator settings are preserved.

### Multisite

- [ ] Shared plugin code with separate DB/table prefix or databases.
- [ ] Separate `path_images`, `images_url` and `path_data`.
- [ ] Confirm Site A cannot write into or serve Site B's storage.
- [ ] Confirm temporary/upload directories are isolated.

### Upload/security regression

- [ ] Browser upload success and invalid/missing CSRF rejection.
- [ ] Four-slot browser upload option association.
- [ ] DNC off/on tests for PNG/GIF/BMP and `discard_original` variants.
- [ ] Executable/double-extension/unknown-MIME rejection.
- [ ] Remote Media public/private/redirect/oversize cases.
- [ ] FTP valid source, forged outside path, unsafe extension and escaping symlink.
- [ ] ZIP import: normal archive, `../` traversal member, symbolic-link member, excessive entry count and >1 GiB declared uncompressed payload.
- [ ] CLI recursive import: normal nested directories, symlink source rejection and correct subdirectory-to-subalbum placement.
- [ ] Batch continuation/cancellation as owner, another user and administrator.
- [ ] Moderated upload/edit/approve/reject with forged album/media binding attempts.
- [ ] Stale-temp cleanup keeps recent/active entries and removes only fully stale trees.

### Functional regression

- [ ] Moderator email HTML/plaintext through Geeklog mail backend.
- [ ] `album_list` service permissions matrix.
- [ ] Media/album canonical output with multiple skins and paginated sort variants.
- [ ] Standard RSS and podcast feed generation under PHP 8.3 without warnings/deprecations.
- [ ] MP3/WMA/MOV/ASF/SWF/FLV legacy-media rendering.
- [ ] ASF/MOV popup/download paths without undefined-variable warnings.
- [ ] Existing `fslideshow.php` URLs and `fslideshow` autotags.

## 13. Final RC cleanup

Before producing the 1.8.0 release candidate:

- [x] Add explicit image-backend capability detection and clear error reporting.
- [ ] Finish live PHP 8.2/8.3 runtime audit.
- [ ] Resolve remaining dead playback/configuration controls.
- [ ] Decide fate of `functions_legacy.inc`; the legacy async upload endpoint has been removed.
- [ ] Complete remaining template/accessibility cleanup without breaking custom skins.
- [ ] Update final `CHANGELOG`, `README` and upgrade documentation.
- [ ] Run the full live-test matrix above.
- [ ] Build and validate the RC ZIP.

## Release principle

MediaGallery 1.8.0 should be safer to upgrade than 1.7.x, keep persistent user media outside replaceable plugin code, work naturally in single-site and shared-code multisite installations, use Geeklog-native services and mail where available, and fail explicitly when required runtime capabilities such as image processing are missing.

- [x] Final public visual polish: meaningful untitled-media fallback, zero-vote rating suppression, compact Search/Options UI, lighter metadata and immersive controls.
