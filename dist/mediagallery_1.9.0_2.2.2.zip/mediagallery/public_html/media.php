<?php
// +--------------------------------------------------------------------------+
// | Media Gallery Plugin - Geeklog                                           |
// +--------------------------------------------------------------------------+
// | media.php                                                                |
// |                                                                          |
// | Handles the display of various media types                               |
// +--------------------------------------------------------------------------+
// | Copyright (C) 2015 by the following authors:                             |
// |                                                                          |
// | Yoshinori Tahara       taharaxp AT gmail DOT com                         |
// |                                                                          |
// | Based on the Media Gallery Plugin for glFusion CMS                       |
// | Copyright (C) 2002-2010 by the following authors:                        |
// |                                                                          |
// | Mark R. Evans          mark AT glfusion DOT org                          |
// +--------------------------------------------------------------------------+
// |                                                                          |
// | This program is free software; you can redistribute it and/or            |
// | modify it under the terms of the GNU General Public License              |
// | as published by the Free Software Foundation; either version 2           |
// | of the License, or (at your option) any later version.                   |
// |                                                                          |
// | This program is distributed in the hope that it will be useful,          |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            |
// | GNU General Public License for more details.                             |
// |                                                                          |
// | You should have received a copy of the GNU General Public License        |
// | along with this program; if not, write to the Free Software Foundation,  |
// | Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.          |
// |                                                                          |
// +--------------------------------------------------------------------------+

require_once '../lib-common.php';

if (!in_array('mediagallery', $_PLUGINS)) {
    COM_redirect($_CONF['site_url'] . '/index.php');
}

if (COM_isAnonUser() && $_MG_CONF['loginrequired'] == 1) {
    $display = SEC_loginRequiredForm();
    $display = MG_createHTMLDocument($display);
    COM_output($display);
    exit;
}

require_once $_CONF['path'] . 'plugins/mediagallery/include/common.php';
require_once $_CONF['path'] . 'plugins/mediagallery/include/lib-media.php';

$msg       = isset($_REQUEST['msg'])  ? COM_applyFilter($_REQUEST['msg'], true) : '';
$full      = isset($_REQUEST['f'])    ? COM_applyFilter($_REQUEST['f'],   true) : 0;
$mid       = isset($_REQUEST['s'])    ? COM_applyFilter($_REQUEST['s'])         : '';
$sortOrder = isset($_REQUEST['sort']) ? COM_applyFilter($_REQUEST['sort'],true) : 0;
$page      = isset($_REQUEST['p'])    ? COM_applyFilter($_REQUEST['p'],   true) : 0;

list($ptitle, $content, $album_id) = MG_displayMedia($mid, $full, $sortOrder, 1, $page);

$skin = DB_getItem($_TABLES['mg_albums'], 'skin', "album_id = ". intval($album_id));
MG_getThemePublicJSandCSS($skin);
$display = '';
if ($msg != '') {
    $display .= COM_showMessage($msg, 'mediagallery');
}
$display .= $content;

// Use one stable public URL for each media item. Parameters controlling
// sorting, pagination or display mode must not create duplicate indexable URLs.
$canonicalUrl = $_MG_CONF['site_url'] . '/media.php?s=' . rawurlencode((string) $mid);
$meta = '<link rel="canonical" href="'
      . htmlspecialchars($canonicalUrl, ENT_QUOTES, COM_getCharset())
      . '"' . XHTML . '>' . LB;

$mediaMeta = array();
$metaResult = DB_query(
    "SELECT media_id, media_filename, media_original_filename, media_mime_ext, mime_type, "
  . "media_title, media_desc, media_type, media_upload_time, media_resolution_x, "
  . "media_resolution_y, remote_media, remote_url, media_tn_attached "
  . "FROM {$_TABLES['mg_media']} WHERE media_id='" . DB_escapeString($mid) . "'"
);
if ($metaResult !== false && DB_numRows($metaResult) === 1) {
    $mediaMeta = DB_fetchArray($metaResult);
}
if (!empty($mediaMeta) && trim(strip_tags(isset($mediaMeta['media_title']) ? $mediaMeta['media_title'] : '')) === '' && $ptitle !== '') {
    $mediaMeta['media_title'] = $ptitle;
}

$mediaDescription = isset($mediaMeta['media_desc']) ? $mediaMeta['media_desc'] : '';
$seoDescription = MG_prepareMetaDescription(PLG_replaceTags($mediaDescription), 160);
if ($seoDescription === '') {
    $seoDescription = MG_prepareMetaDescription($ptitle, 160);
}
if ($seoDescription !== '') {
    $meta .= '<meta name="description" content="' . MG_escapeHTML($seoDescription) . '"' . XHTML . '>' . LB;
}

$mediaType = isset($mediaMeta['media_type']) ? (int) $mediaMeta['media_type'] : -1;
$mediaImage = '';
if (!empty($mediaMeta['media_filename'])) {
    if (!empty($mediaMeta['media_tn_attached'])) {
        $mediaImage = MG_absolutePublicUrl(
            Media::getFileUrl('tn', $mediaMeta['media_filename'], 'jpg', 1)
        );
    } elseif ($mediaType === 0 && !empty($mediaMeta['media_mime_ext'])) {
        $mediaImage = MG_absolutePublicUrl(
            Media::getFileUrl('disp', $mediaMeta['media_filename'], $mediaMeta['media_mime_ext'])
        );
    }
}

$mediaSocialMetadata = array(
    'title' => trim(strip_tags($ptitle)),
    'description' => $seoDescription,
    'url' => $canonicalUrl,
    'type' => $mediaType === 1 ? 'video.other' : 'website',
    'image' => $mediaImage,
    'image_alt' => trim(strip_tags($ptitle)),
    'twitter_card' => $mediaImage !== '' ? 'summary_large_image' : 'summary',
    'item_id' => (string) $mid,
    'subtype' => $mediaType === 0 ? 'image'
        : ($mediaType === 1 ? 'video' : ($mediaType === 2 ? 'audio' : 'media'))
);
if (!MG_delegateSocialMetadata($mediaSocialMetadata)) {
    $meta .= MG_renderSocialMetadata($mediaSocialMetadata);
}

$structuredData = MG_buildMediaStructuredData($mediaMeta, $canonicalUrl);
if (!empty($structuredData)) {
    $meta .= MG_renderJsonLd($structuredData);
}

/*
 * Generic Geeklog public item extension point.
 *
 * Media ids remain the canonical interoperability ids for individual media.
 * Active consumers may append contextual server-rendered fragments.
 */
$itemDisplayFragments = PLG_itemDisplay((string) $mid, 'mediagallery');
if (is_array($itemDisplayFragments)) {
    foreach ($itemDisplayFragments as $itemDisplayFragment) {
        if (is_string($itemDisplayFragment) && $itemDisplayFragment !== '') {
            $display .= $itemDisplayFragment;
        }
    }
}

$display = MG_createHTMLDocument($display, $ptitle, $meta);

COM_output($display);
?>