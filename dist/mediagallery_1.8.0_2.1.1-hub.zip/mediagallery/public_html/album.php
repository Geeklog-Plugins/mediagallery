<?php
// +--------------------------------------------------------------------------+
// | Media Gallery Plugin - Geeklog                                           |
// +--------------------------------------------------------------------------+
// | album.php                                                                |
// |                                                                          |
// | Displays the contents of a MG album                                      |
// +--------------------------------------------------------------------------+
// | Copyright (C) 2015 by the following authors:                             |
// |                                                                          |
// | Yoshinori Tahara       taharaxp AT gmail DOT com                         |
// |                                                                          |
// | Based on the Media Gallery Plugin for glFusion CMS                       |
// | Copyright (C) 2002-2010 by the following authors:                        |
// |                                                                          |
// | Mark R. Evans          mark AT glfusion DOT org                          |
// +--------------------------------------------------------------------------+
// |                                                                          |
// | This program is free software; you can redistribute it and/or            |
// | modify it under the terms of the GNU General Public License              |
// | as published by the Free Software Foundation; either version 2           |
// | of the License, or (at your option) any later version.                   |
// |                                                                          |
// | This program is distributed in the hope that it will be useful,          |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            |
// | GNU General Public License for more details.                             |
// |                                                                          |
// | You should have received a copy of the GNU General Public License        |
// | along with this program; if not, write to the Free Software Foundation,  |
// | Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.          |
// |                                                                          |
// +--------------------------------------------------------------------------+

require_once '../lib-common.php';
require_once $_CONF['path'] . 'plugins/mediagallery/include/common.php';

if (!in_array('mediagallery', $_PLUGINS)) {
    COM_redirect($_CONF['site_url'] . '/index.php');
}

if (COM_isAnonUser() && $_MG_CONF['loginrequired'] == 1) {
    $display = SEC_loginRequiredForm();
    $display = MG_createHTMLDocument($display);
    COM_output($display);
    exit;
}

require_once $_CONF['path'] . 'plugins/mediagallery/include/classAlbum.php';
require_once $_CONF['path'] . 'plugins/mediagallery/include/classMedia.php';

function MG_buildAdminbox(&$album, &$root_album, &$T)
{
    global $_TABLES, $_MG_CONF, $_USER, $LANG_MG01, $LANG_MG03;

    $_MG_USERPREFS = MG_getUserPrefs();
    $isShowUploadMenu = false;
    $isShowAdminMenu  = false;

    if ($root_album->owner_id) {
        $isShowUploadMenu = true;
        $isShowAdminMenu  = true;
    } elseif ($album->access == 3) {
        $isShowUploadMenu = true;
        $isShowAdminMenu  = true;
        if ($_MG_CONF['member_albums']) {
            if ($_MG_USERPREFS['active'] != 1) {
                $isShowUploadMenu = false;
                $isShowAdminMenu  = false;
            } else {
                $isShowUploadMenu = true;
                $isShowAdminMenu  = true;
            }
        }
    } elseif ($album->member_uploads == 1 && isset($_USER['uid']) && $_USER['uid'] >= 2) {
        $isShowUploadMenu = true;
        $isShowAdminMenu  = false;
    }

    $admin_box_option = '';
    if ($isShowUploadMenu) {
        $admin_box_option .= MG_options(array(
            'current' => '',
            'values'  => array('upload' => $LANG_MG01['add_media'])
        ));
    }
    if ($isShowAdminMenu) {
        $admin_box_option .= MG_options(array(
            'current' => '',
            'values'  => array(
                'edit'       => $LANG_MG01['edit_album'],
                'create'     => $LANG_MG01['create_album'],
                'staticsort' => $LANG_MG01['static_sort_media'],
                'media'      => $LANG_MG01['manage_media'],
                'resize'     => $LANG_MG01['resize_display'],
                'rebuild'    => $LANG_MG01['rebuild_thumb'],
            )
        ));
    } elseif ($_MG_CONF['member_albums'] == 1 && !empty($_USER['username']) &&
              $_MG_CONF['member_create_new'] == 1 && $_MG_USERPREFS['active'] == 1 &&
              $album->id == $_MG_CONF['member_album_root']) {
        $admin_box_option .= MG_options(array(
            'current' => '',
            'values'  => array('upload' => $LANG_MG01['create_album'])
        ));
        $isShowAdminMenu = true;
    }

    $admin_box = '';
    if ($isShowUploadMenu || $isShowAdminMenu) {
        $action = $_MG_CONF['site_url'] . '/admin.php';
        $admin_box = '<form name="adminbox" id="adminbox" action="' . $action . '" method="get" class="uk-form"><div>' . LB;
        $admin_box .= '<input type="hidden" name="album_id" value="' . $album->id . '"' . XHTML . '>' . LB;
        $admin_box .= '<select name="mode" onchange="forms[\'adminbox\'].submit()">' . LB;
        $admin_box .= '<option label="' . MG_escapeHTML($LANG_MG01['options']) . '" value="">' . $LANG_MG01['options'] . '</option>' . LB;
        $admin_box .= $admin_box_option;
        $admin_box .= '</select>' . LB;
        $admin_box .= '<input type="submit" value="' . $LANG_MG03['go'] . '"' . XHTML . '>' . LB;
        $admin_box .= '</div></form>' . LB;
    }

    if ($isShowAdminMenu) {
        $url_edit = MG_escapeHTML($_MG_CONF['site_url'] . '/admin.php?album_id=' . $album->id . '&amp;mode=edit');
        $lang_edit = $LANG_MG01['edit'];
        $edit_album = '<a href="' . $url_edit . '">' . $lang_edit . '</a>';
    } else {
        $url_edit = '';
        $lang_edit = '';
        $edit_album = '';
    }

    $T->set_var(array(
        'select_adminbox' => $admin_box,
        'url_edit'        => $url_edit,
        'lang_edit'       => $lang_edit,
        'edit_album'      => $edit_album
    ));
}

function MG_buildSortbox($album_id, $sortOrder, $page)
{
    global $_MG_CONF, $LANG_MG03;

    $action = $_MG_CONF['site_url'] . '/album.php';
    $retval = '<form name="sortbox" id="sortbox" action="' . $action . '" method="get" class="uk-form"><div>' . LB;
    $retval .= '<input type="hidden" name="aid" value="' . $album_id . '"' . XHTML . '>' . LB;
    $retval .= '<input type="hidden" name="page" value="' . $page . '"' . XHTML . '>' . LB;
    $retval .= $LANG_MG03['sort_by'] . ':&nbsp;<select name="sort" onchange="forms[\'sortbox\'].submit()">' . LB;
    $retval .= MG_options(array(
        'current' => $sortOrder,
        'values'  => array(
            '0'  => $LANG_MG03['sort_default'],
            '1'  => $LANG_MG03['sort_default_asc'],
            '2'  => $LANG_MG03['sort_upload'],
            '3'  => $LANG_MG03['sort_upload_asc'],
            '4'  => $LANG_MG03['sort_capture'],
            '5'  => $LANG_MG03['sort_capture_asc'],
            '6'  => $LANG_MG03['sort_rating'],
            '7'  => $LANG_MG03['sort_rating_asc'],
            '8'  => $LANG_MG03['sort_views'],
            '9'  => $LANG_MG03['sort_views_asc'],
            '10' => $LANG_MG03['sort_alpha'],
            '11' => $LANG_MG03['sort_alpha_asc'],
        )
    ));
    $retval .= '</select>' . LB;
    $retval .= '<input type="submit" value="' . $LANG_MG03['go'] . '"' . XHTML . '>' . LB;
    $retval .= '</div></form>' . LB;

    return $retval;
}

$album_id  = isset($_GET['aid'])  ? COM_applyFilter($_GET['aid'], true) : 0;
$page      = isset($_GET['page']) ? COM_applyFilter($_GET['page'], true) : 1;
$sortOrder = isset($_GET['sort']) ? COM_applyFilter($_GET['sort'], true) : 0;
$media_id  = isset($_GET['s'])    ? COM_applyFilter($_GET['s']) : '';

if ($album_id == 0) {
    header('HTTP/1.1 301 Moved Permanently');
    header('Location: ' . $_MG_CONF['site_url'] . '/index.php');
    exit;
}

$_MG_USERPREFS = MG_getUserPrefs();
$root_album = new mgAlbum(0);
$album = new mgAlbum($album_id);

$columns_per_page = ($album->display_columns == 0) ? $_MG_CONF['ad_display_columns'] : $album->display_columns;
$rows_per_page = ($album->display_rows == 0) ? $_MG_CONF['ad_display_rows'] : $album->display_rows;
if (isset($_MG_USERPREFS['display_rows']) && $_MG_USERPREFS['display_rows'] > 0) {
    $rows_per_page = $_MG_USERPREFS['display_rows'];
}
if (isset($_MG_USERPREFS['display_columns']) && $_MG_USERPREFS['display_columns'] > 0) {
    $columns_per_page = $_MG_USERPREFS['display_columns'];
}
$media_per_page = $columns_per_page * $rows_per_page;

if ($page != 0) {
    $page = $page - 1;
} elseif ($media_id != 0) {
    $sql = MG_buildMediaSql(array(
        'album_id'  => $album_id,
        'fields'    => array('media_id'),
        'sortorder' => $sortOrder
    ));
    $result = DB_query($sql);
    $mediaOffset = 0;
    while ($row = DB_fetchArray($result)) {
        if ($media_id == $row['media_id']) {
            break;
        }
        $mediaOffset++;
    }
    if ($album->albums_first) {
        $childCount = $album->getChildCount();
        $page = intval(($mediaOffset + $childCount) / $media_per_page);
    } else {
        $page = intval($mediaOffset / $media_per_page);
    }
}

$errorMessage = '';
if (!isset($album->id)) {
    $errorMessage = $LANG_MG02['albumaccessdeny'];
} elseif ($album->access == 0 || ($album->hidden == 1 && $album->access != 3)) {
    $errorMessage = $LANG_MG02['albumaccessdeny'];
} else {
    $aOffset = $album->getOffset();
    if ($aOffset == -1) {
        $errorMessage = $LANG_MG02['albumaccessdeny'];
    }
}
if ($errorMessage != '') {
    COM_errorLog('Media Gallery Error - User attempted to view an album that does not exist.');
    $display = COM_showMessageText($errorMessage);
    $display = MG_createHTMLDocument($display);
    COM_output($display);
    exit;
}

if ($_MG_CONF['usage_tracking']) {
    MG_updateUsage('album_view', $album->title, '', 0);
}

if (!$root_album->owner_id && $page == 0) {
    $album_views = $album->views + 1;
    DB_change($_TABLES['mg_albums'], 'album_views', intval($album_views), 'album_id', intval($album_id));
}

$begin = $media_per_page * $page;
$end = $media_per_page;
$total_media = 0;
$MG_media = array();

if ($album->albums_first == 1) {
    $children = $album->getChildrenVisible();
    $cCount = count($children);

    for ($i = $begin; $i < $begin + $end; $i++) {
        if ($i >= $cCount) {
            continue;
        }
        $MG_media[] = array('type' => 0, 'obj' => $children[$i]);
        $total_media++;
    }

    $begin = $begin - $cCount;
    if ($begin < 0) {
        $begin = 0;
    }
    $end = $end - $total_media;
} else {
    $cCount = $album->getChildcount();
}

$sql = MG_buildMediaSql(array(
    'album_id'  => $album_id,
    'sortorder' => $sortOrder,
    'offset'    => $begin,
    'limit'     => $end
));
$result = DB_query($sql);
$mediaRows = 0;
while ($row = DB_fetchArray($result)) {
    $MG_media[] = array('type' => 1, 'obj' => new Media($row, $album_id));
    $total_media++;
    $mediaRows++;
}

if ($album->albums_first == 0 && ($begin + $mediaRows) >= $album->media_count) {
    $startingPoint = $begin - $album->media_count;
    if ($startingPoint < 0) {
        $startingPoint = 0;
    }
    $numToProcess = $end - $mediaRows;
    $children = $album->getChildrenVisible();
    $endPoint = min($startingPoint + $numToProcess, count($children));

    for ($i = $startingPoint; $i < $endPoint; $i++) {
        $MG_media[] = array('type' => 0, 'obj' => $children[$i]);
        $total_media++;
    }
}

$total_items_in_album = $album->media_count + $cCount;
$total_pages = ceil($total_items_in_album / $media_per_page);
if ($page >= $total_pages) {
    $page = $total_pages - 1;
}

$start = $page * $media_per_page;
$current_print_page = floor($start / $media_per_page) + 1;
if ($current_print_page == 0) {
    $current_print_page = 1;
}
$total_print_pages = ($total_pages == 0) ? 1 : $total_pages;

$aPage = 1;
if ($aOffset > 0) {
    $aPage = intval($aOffset / ($root_album->display_columns * $root_album->display_rows)) + 1;
}

$birdseed = MG_getBirdseed($album_id, 0, $sortOrder, $aPage);
$ownername = DB_getItem($_TABLES['users'], 'username', 'uid=' . intval($album->owner_id));
$album_last_update = MG_getUserDateTimeFormat($album->last_update);
$pagination = COM_printPageNavigation(
    $_MG_CONF['site_url'] . '/album.php?aid=' . $album_id . '&amp;sort=' . $sortOrder,
    $page + 1,
    $total_pages
);

$rsslink = '';
if ($album->enable_rss) {
    $rssfeedname = sprintf($_MG_CONF['rss_feed_name'] . '%06d', $album_id);
    $rsslink = COM_createLink(
        COM_createImage(MG_getImageFile('feed.png'), '', array('class' => 'mg_rssimg')),
        MG_getFeedUrl($rssfeedname . '.rss'),
        array('type' => 'application/rss+xml')
    );
}

$T = COM_newTemplate(MG_getTemplatePath_byName($album->skin));
$T->set_file('page', 'album_page.thtml');
$T->set_var(array(
    'site_url'           => $_MG_CONF['site_url'],
    'birdseed'           => $birdseed,
    'album_title'        => PLG_replaceTags($album->title),
    'table_columns'      => $columns_per_page,
    'grid_class'         => 'mg-cols-' . max(1, min(10, (int) $columns_per_page)),
    'table_column_width' => intval(100 / $columns_per_page) . '%',
    'top_pagination'     => $pagination,
    'bottom_pagination'  => $pagination,
    'page_number'        => sprintf('%s %d %s %d', $LANG_MG03['page'], $current_print_page, $LANG_MG03['of'], $total_print_pages),
    'jumpbox'            => MG_buildAlbumJumpbox($root_album, $album_id, 1, -1),
    'album_id'           => $album_id,
    'album_description'  => ($album->display_album_desc ? PLG_replaceTags($album->description) : ''),
    'album_id_display'   => ($root_album->owner_id || $_MG_CONF['enable_media_id'] == 1 ? $LANG_MG03['album_id_display'] . $album_id : ''),
    'select_sortbox'     => ($album->enable_sort == 1 ? MG_buildSortbox($album_id, $sortOrder, $page + 1) : ''),
    'album_last_update'  => $album_last_update[0],
    'album_owner'        => $ownername,
    'media_count'        => $album->getMediaCount(),
    'lang_search'        => $LANG_MG01['search'],
    'lang_aria_breadcrumb' => $LANG_MG03['aria_breadcrumb'],
    'lang_aria_album_actions' => $LANG_MG03['aria_album_actions'],
    'lang_aria_album_pagination' => $LANG_MG03['aria_album_pagination'],
    'lang_aria_album_pagination_info' => $LANG_MG03['aria_album_pagination_info'],
    'lang_aria_album_navigation' => $LANG_MG03['aria_album_navigation'],
    'lang_aria_media_list' => $LANG_MG03['aria_media_list'],
    'keywords'           => '',
    'rsslink'            => $rsslink,
    'list_title'         => $LANG_MG03['list_title'],
    'list_desc'          => $LANG_MG03['list_desc'],
    'list_size'          => $LANG_MG03['list_size'],
    'list_user'          => $LANG_MG03['list_user'],
    'list_updated'       => $LANG_MG03['list_updated'],
));
MG_buildAdminbox($album, $root_album, $T);
MG_buildSlideshow($album, $T, $sortOrder);
PLG_templateSetVars('mediagallery', $T);

if ($total_media > 0) {
    $col = 0;
    $opt = array('sortOrder' => $sortOrder);
    $T->set_block('page', 'ImageColumn', 'IColumn');
    $T->set_block('page', 'ImageRow', 'IRow');

    for ($i = 0; $i < $media_per_page; $i += $columns_per_page) {
        $next_columns = $i + $columns_per_page;
        for ($j = $i; $j < $next_columns; $j++) {
            if ($j >= $total_media) {
                $T->parse('IRow', 'ImageRow', true);
                $T->set_var('IColumn', '');
                break 2;
            }

            if ($MG_media[$j]['type'] == 0) {
                $celldisplay = MG_albumThumbnail($MG_media[$j]['obj']);
            } else {
                $celldisplay = $MG_media[$j]['obj']->displayThumb($opt);
                if ($MG_media[$j]['obj']->type == 1) {
                    $T->set_var('URL', MG_getFilePath('disp', $MG_media[$j]['obj']->filename, 'jpg'));
                }
            }

            $T->set_var('clear_float', '');
            if ($col == $columns_per_page) {
                $T->set_var('clear_float', ' clear:both;');
                $col = 0;
            }
            $T->set_var('CELL_DISPLAY_IMAGE', $celldisplay);
            $T->parse('IColumn', 'ImageColumn', true);
            $col++;
        }
        $T->parse('IRow', 'ImageRow', true);
        $T->set_var('IColumn', '');
    }
    $T->set_var('album_body', 1);
} else {
    $T->set_var('lang_no_image', $LANG_MG03['no_media_objects']);
}

MG_getThemePublicJSandCSS($album->skin);
MG_getCSS($album->image_skin);
if ($album->image_skin != $album->album_skin) {
    MG_getCSS($album->album_skin);
}

$display = $T->finish($T->parse('output', 'page'));

$pageTitle = trim(strip_tags(PLG_replaceTags($album->title)));
if ($current_print_page > 1) {
    $pageTitle .= ' - ' . $LANG_MG03['page'] . ' ' . $current_print_page;
}

$canonicalUrl = $_MG_CONF['site_url'] . '/album.php?aid=' . intval($album_id);
if ($current_print_page > 1) {
    $canonicalUrl .= '&page=' . intval($current_print_page);
}
$meta = '<link rel="canonical" href="'
      . htmlspecialchars($canonicalUrl, ENT_QUOTES, COM_getCharset())
      . '"' . XHTML . '>' . LB;

$descriptionLength = ($current_print_page > 1) ? 145 : 160;
$seoDescription = MG_prepareMetaDescription(PLG_replaceTags($album->description), $descriptionLength);
if ($seoDescription === '') {
    $seoDescription = MG_prepareMetaDescription(
        trim(strip_tags(PLG_replaceTags($album->title))),
        $descriptionLength
    );
}
if ($seoDescription !== '') {
    if ($current_print_page > 1) {
        $seoDescription .= ' - ' . $LANG_MG03['page'] . ' ' . $current_print_page;
    }
    $meta .= '<meta name="description" content="' . MG_escapeHTML($seoDescription) . '"' . XHTML . '>' . LB;
}

$albumStructuredItems = array();
$albumSocialImage = '';
foreach ($MG_media as $entry) {
    if (!is_array($entry) || !isset($entry['type'], $entry['obj']) || !is_object($entry['obj'])) {
        continue;
    }

    if ((int) $entry['type'] === 0) {
        $childAlbum = $entry['obj'];
        $childName = isset($childAlbum->title)
            ? trim(strip_tags(PLG_replaceTags($childAlbum->title)))
            : '';
        if (!empty($childAlbum->id) && $childName !== '') {
            $albumStructuredItems[] = array(
                'type' => 'CollectionPage',
                'url' => $_MG_CONF['site_url'] . '/album.php?aid=' . (int) $childAlbum->id,
                'name' => $childName
            );
        }
        continue;
    }

    $mediaObject = $entry['obj'];
    $mediaName = isset($mediaObject->title)
        ? trim(strip_tags(PLG_replaceTags($mediaObject->title)))
        : '';
    if ($mediaName === '' && !empty($mediaObject->filename)) {
        $mediaName = (string) $mediaObject->filename;
    }
    if (empty($mediaObject->id) || $mediaName === '') {
        continue;
    }

    $schemaType = 'CreativeWork';
    if ((int) $mediaObject->type === 0) {
        $schemaType = 'ImageObject';
    } elseif ((int) $mediaObject->type === 1) {
        $schemaType = 'VideoObject';
    } elseif ((int) $mediaObject->type === 2) {
        $schemaType = 'AudioObject';
    }

    $itemImage = '';
    if (!empty($mediaObject->tn_attached)) {
        $itemImage = MG_absolutePublicUrl(
            Media::getFileUrl('tn', $mediaObject->filename, 'jpg', 1)
        );
    } elseif ((int) $mediaObject->type === 0 && !empty($mediaObject->mime_ext)) {
        $itemImage = MG_absolutePublicUrl(
            Media::getFileUrl('disp', $mediaObject->filename, $mediaObject->mime_ext)
        );
    }

    if ($albumSocialImage === '' && $itemImage !== '') {
        $albumSocialImage = $itemImage;
    }

    $albumStructuredItems[] = array(
        'type' => $schemaType,
        'url' => $_MG_CONF['site_url'] . '/media.php?s=' . rawurlencode((string) $mediaObject->id),
        'name' => $mediaName,
        'image' => $itemImage
    );
}

$albumSocialMetadata = array(
    'title' => $pageTitle,
    'description' => $seoDescription,
    'url' => $canonicalUrl,
    'type' => 'website',
    'image' => $albumSocialImage,
    'image_alt' => $pageTitle,
    'twitter_card' => $albumSocialImage !== '' ? 'summary_large_image' : 'summary',
    'item_id' => (string) $album_id,
    'subtype' => 'album'
);
if (!MG_delegateSocialMetadata($albumSocialMetadata)) {
    $meta .= MG_renderSocialMetadata($albumSocialMetadata);
}

$albumStructuredData = MG_buildAlbumStructuredData(
    $album,
    $canonicalUrl,
    $albumStructuredItems,
    $albumSocialImage
);
if (!empty($albumStructuredData)) {
    $meta .= MG_renderJsonLd($albumStructuredData);
}

/*
 * Generic Geeklog public item extension point.
 *
 * MediaGallery only announces the canonical album identity. Consumers such
 * as Hub may contribute contextual fragments without MediaGallery depending
 * on them.
 */
$itemDisplayFragments = PLG_itemDisplay(MG_albumItemId180($album_id), 'mediagallery');
if (is_array($itemDisplayFragments)) {
    foreach ($itemDisplayFragments as $itemDisplayFragment) {
        if (is_string($itemDisplayFragment) && $itemDisplayFragment !== '') {
            $display .= $itemDisplayFragment;
        }
    }
}

$display = MG_createHTMLDocument($display, $pageTitle, $meta);
COM_output($display);
